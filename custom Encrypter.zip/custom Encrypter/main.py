import string


def caesar(text, shift, alphabets):
    def shift_alphabets(alphabet):
        return alphabet[shift:] + alphabet[:shift]

    shifted_alphabets = tuple(map(shift_alphabets, alphabets))
    final_alphabet = ''.join(alphabets)
    final_shifted_alphabet = ''.join(shifted_alphabets)
    table = str.maketrans(final_alphabet, final_shifted_alphabet)
    return text.translate(table)


print("translate = 1")
chose = int(input("Encrypt = 2 \n "))
encrypted_code = int(input("need to be less then 25(first code): "))
N = encrypted_code
second_encrypted_code = int(input("second code(less then 5, 0 - 5): \n "))

if second_encrypted_code == 0:
    res = "34263546875&$^&*%$#&(*^@(*"
if second_encrypted_code == 1:
    res = "#()*a%&$#@!"
    #res = "kwo)ihg4287_+!#(*"
if second_encrypted_code == 2:
    res = "(%^@564_^ba(265"
if second_encrypted_code == 3:
    res = "!8390sab@*(!&_+"
if second_encrypted_code == 4:
    res = "#|^3$@&3)_+)#+sabh"
if second_encrypted_code == 5:
    res = "%@&!#(48sabhf7*#*&(@{}_+|2"

if chose == 1:
    custom = res
    a = 26 - encrypted_code

    plain_text = input("the text: ")
    print(caesar(plain_text, int(a),
                 [string.ascii_lowercase, string.ascii_uppercase, string.punctuation, string.digits,
                  str(custom)]))

    print(custom)
    a = input("")

if chose == 2:

    custom = res

    plain_text = input("the text: ")
    print(caesar(plain_text, encrypted_code,
                 [string.ascii_lowercase, string.ascii_uppercase, string.punctuation, string.digits,
                  str(custom)]))
    print(custom)
    a = input("")


